"""SM Setup - AWS Resource Management CLI Tool."""

__version__ = "0.1.0"
